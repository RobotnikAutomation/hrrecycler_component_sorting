
"use strict";

let RobotnikMoveBaseFlexFeedbackAction = require('./RobotnikMoveBaseFlexFeedbackAction.js');
let RobotnikMoveBaseFlexResultAction = require('./RobotnikMoveBaseFlexResultAction.js');
let PoseStampedArray = require('./PoseStampedArray.js');
let RobotnikMoveBaseFlexGoalAction = require('./RobotnikMoveBaseFlexGoalAction.js');
let RobotnikMoveBaseFlexResult = require('./RobotnikMoveBaseFlexResult.js');
let RobotnikMoveBaseFlexActionGoal = require('./RobotnikMoveBaseFlexActionGoal.js');
let RobotnikMoveBaseFlexGoal = require('./RobotnikMoveBaseFlexGoal.js');
let MoveGoal = require('./MoveGoal.js');
let MoveFeedback = require('./MoveFeedback.js');
let RobotnikMoveBaseFlexAction = require('./RobotnikMoveBaseFlexAction.js');
let DockResult = require('./DockResult.js');
let RobotnikMoveBaseFlexActionResult = require('./RobotnikMoveBaseFlexActionResult.js');
let RobotnikMoveBaseFlexFeedback = require('./RobotnikMoveBaseFlexFeedback.js');
let DockAction = require('./DockAction.js');
let DockActionResult = require('./DockActionResult.js');
let MoveActionResult = require('./MoveActionResult.js');
let DockActionGoal = require('./DockActionGoal.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let MoveAction = require('./MoveAction.js');
let DockGoal = require('./DockGoal.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let MoveResult = require('./MoveResult.js');
let DockFeedback = require('./DockFeedback.js');
let RobotnikMoveBaseFlexActionFeedback = require('./RobotnikMoveBaseFlexActionFeedback.js');
let DockActionFeedback = require('./DockActionFeedback.js');

module.exports = {
  RobotnikMoveBaseFlexFeedbackAction: RobotnikMoveBaseFlexFeedbackAction,
  RobotnikMoveBaseFlexResultAction: RobotnikMoveBaseFlexResultAction,
  PoseStampedArray: PoseStampedArray,
  RobotnikMoveBaseFlexGoalAction: RobotnikMoveBaseFlexGoalAction,
  RobotnikMoveBaseFlexResult: RobotnikMoveBaseFlexResult,
  RobotnikMoveBaseFlexActionGoal: RobotnikMoveBaseFlexActionGoal,
  RobotnikMoveBaseFlexGoal: RobotnikMoveBaseFlexGoal,
  MoveGoal: MoveGoal,
  MoveFeedback: MoveFeedback,
  RobotnikMoveBaseFlexAction: RobotnikMoveBaseFlexAction,
  DockResult: DockResult,
  RobotnikMoveBaseFlexActionResult: RobotnikMoveBaseFlexActionResult,
  RobotnikMoveBaseFlexFeedback: RobotnikMoveBaseFlexFeedback,
  DockAction: DockAction,
  DockActionResult: DockActionResult,
  MoveActionResult: MoveActionResult,
  DockActionGoal: DockActionGoal,
  MoveActionGoal: MoveActionGoal,
  MoveAction: MoveAction,
  DockGoal: DockGoal,
  MoveActionFeedback: MoveActionFeedback,
  MoveResult: MoveResult,
  DockFeedback: DockFeedback,
  RobotnikMoveBaseFlexActionFeedback: RobotnikMoveBaseFlexActionFeedback,
  DockActionFeedback: DockActionFeedback,
};
