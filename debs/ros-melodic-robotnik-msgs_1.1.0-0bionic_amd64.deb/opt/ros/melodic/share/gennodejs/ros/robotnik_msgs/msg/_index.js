
"use strict";

let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let SubState = require('./SubState.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let OdomManualCalibrationStatus = require('./OdomManualCalibrationStatus.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let Alarms = require('./Alarms.js');
let QueryAlarm = require('./QueryAlarm.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let named_input_output = require('./named_input_output.js');
let AlarmSensor = require('./AlarmSensor.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let Pose2DArray = require('./Pose2DArray.js');
let LaserMode = require('./LaserMode.js');
let ptz = require('./ptz.js');
let alarmmonitor = require('./alarmmonitor.js');
let encoders = require('./encoders.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let Axis = require('./Axis.js');
let MotorsStatus = require('./MotorsStatus.js');
let BoolArray = require('./BoolArray.js');
let InverterStatus = require('./InverterStatus.js');
let PresenceSensor = require('./PresenceSensor.js');
let ElevatorAction = require('./ElevatorAction.js');
let MotorPID = require('./MotorPID.js');
let OdomCalibrationStatusStamped = require('./OdomCalibrationStatusStamped.js');
let BatteryStatus = require('./BatteryStatus.js');
let State = require('./State.js');
let StringStamped = require('./StringStamped.js');
let OdomCalibrationStatus = require('./OdomCalibrationStatus.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let Interfaces = require('./Interfaces.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let Data = require('./Data.js');
let StringArray = require('./StringArray.js');
let OdomManualCalibrationStatusStamped = require('./OdomManualCalibrationStatusStamped.js');
let Register = require('./Register.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let MotorStatus = require('./MotorStatus.js');
let LaserStatus = require('./LaserStatus.js');
let inputs_outputs = require('./inputs_outputs.js');
let Registers = require('./Registers.js');
let ReturnMessage = require('./ReturnMessage.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');

module.exports = {
  MotorsStatusDifferential: MotorsStatusDifferential,
  SafetyModuleStatus: SafetyModuleStatus,
  SubState: SubState,
  named_inputs_outputs: named_inputs_outputs,
  OdomManualCalibrationStatus: OdomManualCalibrationStatus,
  PresenceSensorArray: PresenceSensorArray,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  Alarms: Alarms,
  QueryAlarm: QueryAlarm,
  MotorHeadingOffset: MotorHeadingOffset,
  named_input_output: named_input_output,
  AlarmSensor: AlarmSensor,
  alarmsmonitor: alarmsmonitor,
  Pose2DArray: Pose2DArray,
  LaserMode: LaserMode,
  ptz: ptz,
  alarmmonitor: alarmmonitor,
  encoders: encoders,
  ElevatorStatus: ElevatorStatus,
  Axis: Axis,
  MotorsStatus: MotorsStatus,
  BoolArray: BoolArray,
  InverterStatus: InverterStatus,
  PresenceSensor: PresenceSensor,
  ElevatorAction: ElevatorAction,
  MotorPID: MotorPID,
  OdomCalibrationStatusStamped: OdomCalibrationStatusStamped,
  BatteryStatus: BatteryStatus,
  State: State,
  StringStamped: StringStamped,
  OdomCalibrationStatus: OdomCalibrationStatus,
  Pose2DStamped: Pose2DStamped,
  BatteryDockingStatus: BatteryDockingStatus,
  Interfaces: Interfaces,
  BatteryStatusStamped: BatteryStatusStamped,
  Data: Data,
  StringArray: StringArray,
  OdomManualCalibrationStatusStamped: OdomManualCalibrationStatusStamped,
  Register: Register,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  MotorStatus: MotorStatus,
  LaserStatus: LaserStatus,
  inputs_outputs: inputs_outputs,
  Registers: Registers,
  ReturnMessage: ReturnMessage,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorAction: SetElevatorAction,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
};
